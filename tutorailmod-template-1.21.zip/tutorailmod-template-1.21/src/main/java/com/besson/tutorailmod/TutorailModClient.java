package com.besson.tutorailmod;

import net.fabricmc.api.ClientModInitializer;

public class TutorailModClient  implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

    }
}
